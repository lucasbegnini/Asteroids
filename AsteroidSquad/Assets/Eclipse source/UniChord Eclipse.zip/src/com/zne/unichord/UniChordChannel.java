package com.zne.unichord;

import java.util.List;
import java.util.HashMap;

import android.util.Log;

import com.samsung.chord.IChordChannel;

public class UniChordChannel 
{
	private static final String TAG = "UniChordChannel";
	private static HashMap<String,IChordChannel> _channel_map = new HashMap<String,IChordChannel>();
	
	
	public static void AddChannel( String channel_name, IChordChannel channel )
	{
		if( !_channel_map.containsKey(channel_name) )
			_channel_map.put(channel_name, channel);
	}

	public static void DelChannel( String channel_name )
	{
		if( _channel_map.containsKey(channel_name) )
			_channel_map.remove(channel_name);
	}

	public static void DelAllChannels()
	{
		_channel_map.clear();
	}
	
	private static IChordChannel GetChannel( String channel_name )
	{
		if( _channel_map.containsKey(channel_name) )
			return _channel_map.get(channel_name);
		
		return null;
	}
	
	// Accept to receive file.
	public static boolean acceptFile(String channel_name, String exchangeId, long chunkTimeoutMsec, int chunkRetries, long chunkSize)
	{
		Log.d(TAG, "acceptFile, channelName=" + channel_name + ", exchangeId=" + exchangeId);
    	IChordChannel channel = GetChannel(channel_name);
    	if( channel != null )
    	{
    		Log.d(TAG, "acceptFile find channel");

    		boolean ret = channel.acceptFile(exchangeId, chunkTimeoutMsec, chunkRetries, chunkSize);
    		if( ret )
    			Log.d(TAG, "acceptFile success!");
    		else
    			Log.d(TAG, "acceptFile failed!");
  			
  			return ret; 
    	}
    	else
    	{
    		Log.d(TAG, "acceptFile failed. can't found channel");
    		return false;
    	}
	}

    // Cancel file transfer.
	public static boolean cancelFile(String channel_name, String exchangeId)
	{
		Log.d(TAG, "cancelFile, channelName=" + channel_name + ", exchangeId=" + exchangeId);
    	IChordChannel channel = GetChannel(channel_name);
    	if( channel != null )
    	{
    		Log.d(TAG, "cancelFile find channel");

    		boolean ret = channel.cancelFile(exchangeId);
    		if( ret )
    			Log.d(TAG, "cancelFile success!");
    		else
    			Log.d(TAG, "cancelFile failed!");
  			
  			return ret; 
    	}
    	else
    	{
    		Log.d(TAG, "cancelFile failed. can't found channel");
    		return false;
    	}
	}

    // Requests for nodes on the channel.
    public static String getJoinedNodeList( String channel_name )
    {
    	IChordChannel channel = GetChannel(channel_name);
    	if( channel != null )
    	{
    		List<String> node_list = channel.getJoinedNodeList();
    		return UniChordPackedString.SerializePacket(node_list.toArray( new String[node_list.size()]));
    	}
    		
    	return null;
    }

    // It's no use here, proccessed by unity's UniChordChannel
    // getName()
    
    
    // Get an IPv4 address that the node has.
    public static String getNodeIpAddress(String channel_name, String nodeName)
    {
    	IChordChannel channel = GetChannel(channel_name);
    	if( channel != null )
    	{
    		return channel.getNodeIpAddress(nodeName);
    	}

    	return null;
    }

    // It's no use here, proccessed by unity's UniChordChannel
    // isName()

    // Reject to receive file.
    public static boolean rejectFile(String channel_name, String exchangeId)
    {
    	Log.d(TAG, "rejectFile, channelName=" + channel_name + ", exchangeId=" + exchangeId);
    	IChordChannel channel = GetChannel(channel_name);
    	if( channel != null )
    	{
    		Log.d(TAG, "rejectFile find channel");

    		boolean ret = channel.rejectFile(exchangeId);
    		if( ret )
    			Log.d(TAG, "rejectFile success!");
    		else
    			Log.d(TAG, "rejectFile failed!");
  			
  			return ret; 
    	}
    	else
    	{
    		Log.d(TAG, "rejectFile failed. can't found channel");
    		return false;
    	}
    }
    
    // Send data message to the node.
    // [����] AndroidJavaClass �� byte[][] ����� �Ҽ� ���⶧���� string[]���� ��ü�Ѵ�.
    public static boolean sendData(String channel_name, String toNode, String payloadType, String payload)
    {
    	IChordChannel channel = GetChannel(channel_name);
    	if( channel != null )
    	{
    		byte[][] bin_payload = null;
    		if( payload != null )
    		{
    			bin_payload = new byte[1][];
    			bin_payload[0] = payload.getBytes();
    		}
    		
    		return channel.sendData(toNode, payloadType, bin_payload);
    	}
    	return false;
    }

    // Send data message to the all nodes on the channel.
    // [����] AndroidJavaClass �� byte[][] ����� �Ҽ� ���⶧���� string[]���� ��ü�Ѵ�.
    public static boolean sendDataToAll(String channel_name, String payloadType, String payload)
    {
    	Log.d(TAG, "sendDataToAll, channelName=" + channel_name + ", payload=" + payload);
    	IChordChannel channel = GetChannel(channel_name);
    	if( channel != null )
    	{
    		Log.d(TAG, "sendDataToAll find channel");
    		byte[][] bin_payload = null;
    		if( payload != null )
    		{
    			bin_payload = new byte[1][];
    			bin_payload[0] = payload.getBytes();
    		}
    		boolean ret = channel.sendDataToAll( payloadType, bin_payload);
    		
    		if( ret )
    			Log.d(TAG, "sendDataToAll success!");
    		else
    			Log.d(TAG, "sendDataToAll failed!");
    		
    	}
    	else
    	{
    		Log.d(TAG, "sendDataToAll failed. can't found channel");
    	}
    	
    	return false;
    }

    // Send file to specific node on the channel.
    public static String sendFile(String channel_name, String toNode, String fileType, String filePath, long timeoutMsec)
    {
    	Log.d(TAG, "sendFile, channelName=" + channel_name + ", toNode=" + toNode + "filePath=" + filePath);
    	IChordChannel channel = GetChannel(channel_name);
    	if( channel != null )
    	{
    		Log.d(TAG, "sendFile find channel");

    		String exchangedId = channel.sendFile(toNode, fileType, filePath, timeoutMsec);
  			Log.d(TAG, "sendFile success! exchangedId=" + exchangedId);
  			
  			return exchangedId; 
    	}
    	else
    	{
    		Log.d(TAG, "sendFile failed. can't found channel");
    		return "";
    	}
    
    }
}
