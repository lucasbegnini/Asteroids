package com.zne.unichord;

//import android.util.Log;

import com.samsung.chord.IChordChannelListener;
import com.unity3d.player.UnityPlayer;

public class UniChordChannelListener implements IChordChannelListener
{
	private static final String UNITY_OBJECT_NAME = "UniChordMessageReceiver";
	//private static final String TAG = "UniChordChannelListener";
	
    // Called when the data message received from the node.
	public void onDataReceived(String fromNode, String fromChannel, String payloadType, byte[][] payload)
	{
		String data_packet = UniChordPackedString.MakeReceivedDataPacket(fromNode, fromChannel, payloadType, payload);
		UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onDataReceived", data_packet );
	}

	// Called when an individual chunk of the file is received.
    public void	onFileChunkReceived(String fromNode, String fromChannel, String fileName, String hash, String fileType, String exchangeId, long fileSize, long offset)
    {
    	String[] string_src = new String[] { fromNode, fromChannel, fileName, hash, fileType, exchangeId, String.valueOf(fileSize), String.valueOf(offset)};
    	String packet = UniChordPackedString.SerializePacket(string_src);
    	UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onFileChunkReceived", packet );
    }
    
    // Called when an individual chunk of the file is sent.
    public void	onFileChunkSent(String toNode, String toChannel, String fileName, String hash, String fileType, String exchangeId, long fileSize, long offset, long chunkSize)
    {
    	String[] string_src = new String[] { toNode, toChannel, fileName, hash, fileType, exchangeId, String.valueOf(fileSize), String.valueOf(offset), String.valueOf(chunkSize)};
    	String packet = UniChordPackedString.SerializePacket(string_src);
    	UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onFileChunkSent", packet );
    }

    // Called when the error is occurred while the file transfer is in progress.
    public void	onFileFailed(String node, String channel, String fileName, String hash, String exchangeId, int reason)
    {
    	String[] string_src = new String[] { node, channel, fileName, hash, exchangeId, String.valueOf(reason)};
    	String packet = UniChordPackedString.SerializePacket(string_src);
    	UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onFileFailed", packet );
    }

    // Called when the file transfer is completed from the node.
    public void	onFileReceived(String fromNode, String fromChannel, String fileName, String hash, String fileType, String exchangeId, long fileSize, String tmpFilePath)
    {
    	String[] string_src = new String[] { fromNode, fromChannel, fileName, hash, fileType, exchangeId, String.valueOf(fileSize), tmpFilePath};
    	String packet = UniChordPackedString.SerializePacket(string_src);
    	UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onFileReceived", packet );
    }

    // Called when the file transfer is completed to the node.
    public void	onFileSent(String toNode, String toChannel, String fileName, String hash, String fileType, String exchangeId)
    {
    	String[] string_src = new String[] { toNode, toChannel, fileName, hash, fileType, exchangeId };
    	String packet = UniChordPackedString.SerializePacket(string_src);
    	UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onFileSent", packet );
    }

    // Called when the Share file notification is received.
    public void	onFileWillReceive(String fromNode, String fromChannel, String fileName, String hash, String fileType, String exchangeId, long fileSize)
    {
    	String[] string_src = new String[] { fromNode, fromChannel, fileName, hash, fileType, exchangeId, String.valueOf(fileSize) };
    	String packet = UniChordPackedString.SerializePacket(string_src);
    	UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onFileWillReceive", packet );
    }

    // Called when a node join event is raised on the channel.
    public void	onNodeJoined(String fromNode, String fromChannel)
    {
    	String[] string_src = new String[] { fromNode, fromChannel};
    	String packet = UniChordPackedString.SerializePacket(string_src);
    	UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onNodeJoined", packet );
    }

    // Called when a node leave event is raised on the channel.
    public void	onNodeLeft(String fromNode, String fromChannel)
    {
    	String[] string_src = new String[] { fromNode, fromChannel};
    	String packet = UniChordPackedString.SerializePacket(string_src);
    	UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onNodeLeft", packet );
    }
    
}
