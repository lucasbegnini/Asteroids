// Copyright (C) 2013 ZNE Education. All rights reserved.


package com.zne.unichord;

import com.zne.unichord.UniChordChannelListener;

import java.util.List;

import android.util.Log;
import android.os.Build;
//import android.os.Environment;
import android.os.Looper;
//import android.content.Context;
import android.app.Activity;

import com.samsung.chord.ChordManager;
import com.samsung.chord.IChordChannel;


public class UniChordManager
{
	private static final String TAG = "UniChordManager";
	
	// ------------ About singleton ---------------
	private static UniChordManager m_instance;
	public static UniChordManager instance()
	{
		if( m_instance == null )
			m_instance = new UniChordManager();
		return m_instance;
	}
	// ---------------------------------------------
	
	private ChordManager m_chord_mgr;
	private UniChordChannelListener m_channel_listener = new UniChordChannelListener();

	
	// Minimum api level to running chord sdk.
	private static final int MIN_APILEVEL = 14; 
	
	public ChordManager GetChordManager()
	{
		return 	m_chord_mgr;
	}
	
	// TEST
	/*
	public static String DataSendTestStatic( String str1, String str2, String str3, String str4 )
	{
		String ret = str1 + "+" + str2 + "+" + str3 + "+" + str4;
		return ret;
	}

	public static String ReturnNullStatic( String str1, String str2, String str3, String str4 )
	{
		return null;
	}

	public static byte[] DataSendTestStatic( byte[] data )
	{
		return data;
	}
	
	public byte[] DataSendTest( byte[] data )
	{
		return data;
	}
	*/
	
	// Is supported chord sdk on this device
	public static boolean IsSupported()
	{
		boolean is_supported = (Build.VERSION.SDK_INT >= MIN_APILEVEL);
		Log.d(TAG, "IsSupported=" + is_supported);
		
		return is_supported;
	}
		
	// getInstance
	public boolean getInstance( Activity context )
	{
		if( IsSupported() && m_chord_mgr == null )
		{
			/*
			Context app_context = activity.getApplicationContext();
			m_chord_mgr = ChordManager.getInstance(app_context);
			*/
			
			m_chord_mgr = ChordManager.getInstance(context);
			
			if( m_chord_mgr != null )
			{
				Log.d(TAG, "getInstance success!");

				/*
				String def_temp_dir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/UniChord";
				m_chord_mgr.setTempDirectory(def_temp_dir);
				m_chord_mgr.setHandleEventLooper(context.getMainLooper());
				*/
				return true;
			}
			else
			{
				Log.d(TAG, "getInstance failed, ChordManager.getInstance return null!");
			}
		}
		
		return false;
	}
	
	// getAvailableInterfaceTypes
	public int[] getAvailableInterfaceTypes()
	{
		if( m_chord_mgr != null )
		{
			List<Integer> interface_list = m_chord_mgr.getAvailableInterfaceTypes();
			
			if( interface_list != null && interface_list.size() > 0)
			{
				int[] int_array = new int[interface_list.size()];
				for( int i=0; i<interface_list.size(); i++ )
				{
					int_array[i] = interface_list.get(i);

					switch( int_array[i] )
					{
						case ChordManager.INTERFACE_TYPE_WIFI:
							Log.d(TAG, "INTERFACE_TYPE_WIFI Available");
							break;
							
						case ChordManager.INTERFACE_TYPE_WIFIP2P:
							Log.d(TAG, "INTERFACE_TYPE_WIFIP2P Available");
							break;

						case ChordManager.INTERFACE_TYPE_WIFIAP:
							Log.d(TAG, "INTERFACE_TYPE_WIFIAP Available");
							break;
					}
					
				}
					
				return int_array;
			}
			else
			{
				Log.d(TAG, "All INTERFACE_TYPE NoAvailable!");
			}
		}
		else
		{
			Log.d(TAG, "getAvailableInterfaceTypes failed, m_chord_mgr is null!");
		}
		
		return new int[] {};
	}
	
	// getIp
	public String getIp()
	{
		if( m_chord_mgr != null )
		{
			String ip = m_chord_mgr.getIp();
			Log.d(TAG, "getIp=" + ip);
			return ip;
		}
		else
		{
			Log.d(TAG, "getIp failed, m_chord_mgr is null!");
		}
		
		return null;
	}
	
	// getJoinedChannel
	// [No use] It's managed by Unity's UniChordManager

    // getJoinedChannelList
	// [No use] It's managed by Unity's UniChordManager

    // getName
    public String getName()
    {
    	if( m_chord_mgr != null )
		{
			String nodeName = m_chord_mgr.getName();
			Log.d(TAG, "getName=" + nodeName);
			return nodeName;
		}
		else
		{
			Log.d(TAG, "getName failed, m_chord_mgr is null!");
		}
		
		return null;
    }

    // joinChannel
    public boolean joinChannel(String channelName)
    {
    	if( m_chord_mgr != null )
		{
			IChordChannel channel = m_chord_mgr.joinChannel(channelName, m_channel_listener);
			if( channel != null )
			{
				Log.d(TAG, "joinChannel successed. channelName=" + channelName);
				UniChordChannel.AddChannel(channelName, channel);
				return true;
			}
			else
				Log.d(TAG, "joinChannel failed. channelName=" + channelName);
		}
		else
		{
			Log.d(TAG, "joinChannel failed, m_chord_mgr is null!");
		}
		
		return false;
    }
    

    // leaveChannel
    public void leaveChannel(String channelName)
    {
    	if( m_chord_mgr != null )
		{
			m_chord_mgr.leaveChannel(channelName);
			UniChordChannel.DelChannel(channelName);
			Log.d(TAG, "leaveChannel successed. channelName=" + channelName);
		}
		else
		{
			Log.d(TAG, "leaveChannel failed, m_chord_mgr is null!");
		}
    }
    
    // setHandleEventLooper
    public void setHandleEventLooper( Looper looper)
    {
    	if( m_chord_mgr != null )
		{
    		m_chord_mgr.setHandleEventLooper(looper);
			Log.d(TAG, "setHandleEventLooper successed.");
		}
		else
		{
			Log.d(TAG, "setHandleEventLooper failed, m_chord_mgr is null!");
		}
    }
    
	// setNetworkListener
	public boolean setNetworkListener()
	{
		if( m_chord_mgr != null )
		{
			boolean ret = m_chord_mgr.setNetworkListener( new UniChordManagerNetworkListener() );
			if( ret )
			{
				Log.d(TAG, "setNetworkListener success!");
				return true;
			}
			else
				Log.d(TAG, "setNetworkListener failed!");
		}
		else
		{
			Log.d(TAG, "setNetworkListener failed, m_chord_mgr is null!");
		}
	
		return false;
	}
	
	// setNodeKeepAliveTimeout
	public void setNodeKeepAliveTimeout( long timeoutMsec )
	{
		if( m_chord_mgr != null )
		{
			m_chord_mgr.setNodeKeepAliveTimeout(timeoutMsec);
			Log.d(TAG, "setNodeKeepAliveTimeout success!");
		}
		else
		{
			Log.d(TAG, "setNodeKeepAliveTimeout failed, m_chord_mgr is null!");
		}
	}
	
	// setTempDirectory
	public void setTempDirectory( String temp_dir )
	{
		if( m_chord_mgr != null )
		{
			m_chord_mgr.setTempDirectory(temp_dir);
			Log.d(TAG, "setTempDirectory success!");
		}
		else
		{
			Log.d(TAG, "setTempDirectory failed, m_chord_mgr is null!");
		}
	}
	
	// start
	public int start( int interfaceType )
	{
		if( IsSupported() && m_chord_mgr != null )
		{
			int error = m_chord_mgr.start(interfaceType, new UniChordManagerListener() );
			
			switch( error )
			{
			case ChordManager.ERROR_NONE:
				Log.d(TAG, "UniChord Start success!");
				break;
				
			case ChordManager.ERROR_INVALID_INTERFACE:
				Log.d(TAG, "UniChord Start failed! error=ERROR_INVALID_INTERFACE");
				break;
			
			default:
				Log.d(TAG, "UniChord Start failed! error=" + error);
				break;
				
			}
			 
			return error;
		}
		
		Log.d(TAG, "UniChord Start failed!");
		
		return -1;
	}
	
	// stop
	public void stop()
	{
		if (m_chord_mgr != null) 
		{
			m_chord_mgr.stop();
			m_chord_mgr = null;
			UniChordChannel.DelAllChannels();
            Log.d(TAG, "UniChord Stoped and unregistered");		
		}
		else
		{
			Log.d(TAG, "UniChord Stop failed. m_chord_mgr is null!");
		}
	}
	
	
}
