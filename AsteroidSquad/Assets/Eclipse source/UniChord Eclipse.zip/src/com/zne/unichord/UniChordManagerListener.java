package com.zne.unichord;

import android.util.Log;

import com.samsung.chord.IChordManagerListener;
import com.unity3d.player.UnityPlayer;

public class UniChordManagerListener implements IChordManagerListener 
{
	private static final String UNITY_OBJECT_NAME = "UniChordMessageReceiver";
	private static final String TAG = "UniChordManagerListener";
	
     public void onStarted(String name, int reason) 
     {
    	 Log.d(TAG, "onStarted name=" + name + ", reason=" + reason);
    	 
    	 String packed_string = UniChordPackedString.SerializePacket( new String[] {name, Integer.toString(reason)} );
    	 UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onStarted", packed_string); 	
     }

     public void onNetworkDisconnected() 
     {
    	 Log.d(TAG, "onNetworkDisconnected");
    	 
    	 UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onNetworkDisconnected", null );
     }

     
     public void onError(int error) 
     {
    	 Log.d(TAG, "onError error=" + error);
    	 
    	 UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onError", Integer.toString(error) );
     }

}
