package com.zne.unichord;

import android.util.Log;

import com.samsung.chord.ChordManager.INetworkListener;
import com.unity3d.player.UnityPlayer;

public class UniChordManagerNetworkListener implements INetworkListener
{
	private static final String UNITY_OBJECT_NAME = "UniChordMessageReceiver";
	private static final String TAG = "UniChordManagerNetworkListener";
	
	 public void onConnected(int interfaceType) 
	 {
		 Log.d(TAG, "onConnected interfaceType=" + interfaceType);
		 
		 UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onConnected", Integer.toString(interfaceType));
     }

     public void onDisconnected(int interfaceType) 
     {
    	 Log.d(TAG, "onDisconnected interfaceType=" + interfaceType);
    	 
    	 UnityPlayer.UnitySendMessage(UNITY_OBJECT_NAME, "onDisconnected", Integer.toString(interfaceType));
     }
}
