package com.zne.unichord;

public class UniChordPackedString 
{
    static final String SEPARATOR_REPLACE = "(^_^/";
    static final String SEPARATOR = "(*v^/";
    
    // SerializePacket
    public static String SerializePacket(String[] string_array)
    {
        String packet = "";
        int count = string_array.length;
        for (int i = 0; i < count; i++)
        {
            // if has SEPARATOR in source string, replace to SEPARATOR_REPLACE.
            packet += string_array[i].replace(SEPARATOR, SEPARATOR_REPLACE);

            if (i != count - 1)
                packet += SEPARATOR;
        }

        return packet;
    }

    // SerializePacket
    public static String MakeReceivedDataPacket( String fromNode, String fromChannel, String payloadType, byte[][] payload )
    {
        String packet = fromNode + SEPARATOR + fromChannel + SEPARATOR + payloadType;
        
        if( payload != null )
        	packet += SEPARATOR + new String(payload[0]);
        
        return packet;
    }

    
    // DeserializePacket
    public static String[] DeserializePacket( String packet )
    {
        String[] string_array = packet.split(SEPARATOR);
        return string_array;
    }
}
